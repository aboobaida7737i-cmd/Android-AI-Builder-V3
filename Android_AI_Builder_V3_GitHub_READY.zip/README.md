# Android AI Builder V3
Native Android project. The app lets the user select an Android-project ZIP and upload its files to a GitHub repository using the GitHub Contents API. A GitHub Actions workflow in the repository builds the uploaded Android project as a real APK with Gradle.

Codemagic configuration is included in `codemagic.yaml` at repository root. The project targets Android 5.0+ (minSdk 21).
