package com.example.androidaibuilder;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 1001;
    private EditText token, repo; private TextView log, fileName; private ProgressBar progress; private Uri zipUri;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_main);
        token=findViewById(R.id.token); repo=findViewById(R.id.repo); log=findViewById(R.id.log); fileName=findViewById(R.id.fileName); progress=findViewById(R.id.progress);
        findViewById(R.id.selectZip).setOnClickListener(v -> pickZip()); findViewById(R.id.start).setOnClickListener(v -> startBuild());
    }
    private void pickZip(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_ZIP); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK_ZIP&&c==RESULT_OK&&d!=null){zipUri=d.getData(); fileName.setText(zipUri!=null?zipUri.toString():"لم يتم اختيار ملف");}}
    private void addLog(String s){runOnUiThread(()->log.append("\n"+s));}
    private void setBusy(boolean x){runOnUiThread(()->{progress.setVisibility(x?View.VISIBLE:View.GONE); findViewById(R.id.start).setEnabled(!x);});}
    private void startBuild(){ final String t=token.getText().toString().trim(), r=repo.getText().toString().trim(); if(t.isEmpty()||r.isEmpty()||zipUri==null){addLog("أدخل Token والمستودع واختر ZIP أولاً.");return;} if(!r.matches("[^/\\s]+/[^/\\s]+")){addLog("صيغة المستودع يجب أن تكون username/repository");return;} setBusy(true); log.setText("بدء الرفع..."); executor.execute(()->{try{uploadZip(t,r); addLog("اكتمل الرفع. GitHub Actions سيبدأ البناء تلقائياً.");}catch(Exception e){addLog("خطأ: "+e.getMessage());}finally{setBusy(false);}});}

    private void uploadZip(String t,String r) throws Exception {
        Map<String,byte[]> files=new LinkedHashMap<>();
        try(InputStream in=getContentResolver().openInputStream(zipUri); ZipInputStream zin=new ZipInputStream(in)){
            ZipEntry e; byte[] buf=new byte[8192];
            while((e=zin.getNextEntry())!=null){ if(e.isDirectory())continue; String p=e.getName().replace('\\','/'); if(p.startsWith("/")||p.contains("../")||p.equals(".."))continue; ByteArrayOutputStream out=new ByteArrayOutputStream(); int n; while((n=zin.read(buf))>0)out.write(buf,0,n); files.put(p,out.toByteArray()); }
        }
        if(files.isEmpty()) throw new Exception("ملف ZIP فارغ");
        files=stripSingleRoot(files); addLog("عدد ملفات المشروع: "+files.size());
        int i=0; for(Map.Entry<String,byte[]> en:files.entrySet()){ put(t,r,en.getKey(),en.getValue()); i++; if(i%5==0||i==files.size())addLog("رفع "+i+"/"+files.size()); }
        // Ensure the native build workflow exists in the target repository.
        String workflow = "name: Build Native APK\non:\n  push:\n    branches: ['**']\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: '17'\n      - uses: android-actions/setup-android@v3\n      - name: Android SDK\n        run: |\n          yes | sdkmanager --licenses >/dev/null || true\n          sdkmanager \"platform-tools\" \"platforms;android-35\" \"build-tools;35.0.0\"\n      - name: Build Native APK\n        run: |\n          test -f ./gradlew || (echo 'Missing Gradle Wrapper: gradlew' && exit 1)\n          chmod +x ./gradlew\n          ./gradlew assembleDebug --no-daemon\n      - uses: actions/upload-artifact@v4\n        with:\n          name: android-native-apk\n          path: '**/build/outputs/apk/**/*.apk'\n          if-no-files-found: error\n          retention-days: 7\n";
        put(t,r,".github/workflows/build-apk.yml",workflow.getBytes(StandardCharsets.UTF_8));
    }
    private Map<String,byte[]> stripSingleRoot(Map<String,byte[]> src){String root=null; boolean can=true; for(String p:src.keySet()){int x=p.indexOf('/'); if(x<1){can=false;break;} String a=p.substring(0,x); if(root==null)root=a; else if(!root.equals(a)){can=false;break;}} if(!can)return src; Map<String,byte[]> out=new LinkedHashMap<>(); for(Map.Entry<String,byte[]> e:src.entrySet()){String p=e.getKey().substring(root.length()+1); if(!p.isEmpty())out.put(p,e.getValue());} return out;}

    private void put(String token,String repo,String path,byte[] data)throws Exception{
        String url="https://api.github.com/repos/"+repo+"/contents/"+encPath(path); String sha=null;
        try{JSONObject old=request(token,"GET",url,null); sha=old.optString("sha",null);}catch(Exception ignored){}
        JSONObject body=new JSONObject(); body.put("message","Android AI Builder upload: "+path); body.put("content",Base64.encodeToString(data,Base64.NO_WRAP)); if(sha!=null)body.put("sha",sha); request(token,"PUT",url,body.toString());
    }
    private String encPath(String p){StringBuilder s=new StringBuilder(); for(String part:p.split("/",-1)){if(s.length()>0)s.append('/'); try{s.append(URLEncoder.encode(part,"UTF-8").replace("+","%20"));}catch(Exception e){s.append(part);}} return s.toString();}
    private JSONObject request(String token,String method,String url,String body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(20000); c.setReadTimeout(30000); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Accept","application/vnd.github+json"); c.setRequestProperty("X-GitHub-Api-Version","2022-11-28"); c.setRequestProperty("Content-Type","application/json"); if(body!=null){c.setDoOutput(true); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String txt=""; if(is!=null){ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=is.read(b))>0)o.write(b,0,n); txt=o.toString("UTF-8");} if(code<200||code>=300)throw new Exception("GitHub HTTP "+code+": "+txt); return txt.isEmpty()?new JSONObject():new JSONObject(txt);
    }
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
